/*****************************************
*gcc -g -c mymallocteste.c
*gcc -g -o mymallocteste mymallocteste.c mymalloc.o 
*****************************************/
#include <stdio.h>
#include <stdlib.h>
#include "mymalloc.h"

int main(int argc, char *argv[])
{
    debug_print("Heap size is %d\n",sizeof(Block));
    
    //teste que requesita 0 de memoria, deve retornar null
    char *fail = (char *)myMalloc(0);
    if(fail != NULL) {
      printf("Falha no Teste: aloque mais espaco.\n");
    }
    
    myFree(fail); // nao deve dar free -- ponteiro e nulo
    
    
    //testa algumas alocacoes simples/frees
    
    char *r = (char *)myMalloc(10000*sizeof(char));
    memoryMap();
    
    double *q = (double *)myMalloc(50000*sizeof(double));
    memoryMap();
    
    myFree(r);
    memoryMap();
    
    myFree(r); //nao deve dar free -- ponteiro ja ficou livre
    
    myFree(q+1); //nao deve dar free -- q+1 nao aponta para um local no bloco
    myFree(q);
    memoryMap();
    
    void *toobig = myMalloc(HEAP_SIZE + 1); // nao deve alocar -- grande demais
    if(toobig != NULL) {
      printf("Falha no Teste: aloque menos espaco.\n");
    }
    
    char *s[4];
    int toalloc[4] = { 250000,480000,50000,100000};
    int i;
    
    for(i=0; i<4; i++) {
      s[i] = myMalloc(toalloc[i]);
    }
    
    memoryMap();
    myFree(s[3]);
    myFree(s[1]);
    memoryMap();
    myFree(s[0]);
    myFree(s[2]);
    memoryMap();
    
    return 0;
}