Para executar mymallocteste: ./mymallocteste --thread=t --size=s --count=c --loop=l
Para executar mymallocteste: ./mallocteste --thread=t --size=s --count=c --loop=l
(substituir as letras pelas entradas abaixo.
Os testes que devem se realizados tiveram as seguntes entradas:
--thread=2 --size=5 --count=5 --loop=5
--thread=4 --size=10 --count=10 --loop=10
--thread=8 --size=20 --count=20 --loop=20

O myMalloc utiliza o conceito de blocos e lista de memória, foi levado em consideração o uso de mapa de memória, mas levando em conta que o mapa de memória não tem a possibilidade de aumentar seu tamanho durante a execução, ele foi descartado, o algoritmo para decidir que bloco usar é o FIRST FIT por ser o mais facil de se implementar e o mais rápido, aconteceu a tentativa de usar o BEST FIT, mas resultou em várias falhas e devido ao tempo restante foi necessário usar o FIRST FIT. Uma das pricipais vantagens do mymalloc é que ele é threadsafe.

Thread Safety: é um conceito de programação de computadores aplicável no contexto de programas multi-thread. Um pedaço de código é dito thread-safe se ele apenas manipula estruturas de dados compartilhadas de uma forma que garanta uma execução segura através de várias threads ao mesmo tempo

O mymallocteste foi pensado em explorar ao maximo as vatagens do mymalloc,  ele é um programa multithread para aproveitar o threadsafety do mymalloc. Ele aloca muita memória para mostrar a vantagem de se usar um lista de memória e ultiliza a biblioteca App.h fornecida pela professora Juliana para calcular o tempo de parede.

Bibliografias:  https://pt.wikipedia.org/wiki/Thread_safety
		http://stackoverflow.com/questions/10706466/how-does-malloc-work-in-a-multithreaded-environment
		http://stackoverflow.com/questions/9989496/malloc-and-freeing-memory-between-threads-in-c
		http://www.inf.puc-rio.br/~inf1007/material/slides/alocacaodinamica.pdf
		http://tldp.org/LDP/tlk/mm/memory.html
	Livro: The Linux Programming Interface
